
drop table mcq;

create table mcq(mcq_id int,que varchar(255),option varchar(255),answer varchar(20));

insert into mcq values(1,'what is value of PI?','[A].2 [B].3.14 [C].6 [D].9','B');
insert into mcq values(2,'who is the father of computers?','[A].jamesGosling [B].charlesBubbage [C].DennisRitchie [D].BjarneStroutrup','B');
insert into mcq values(3,'what is full form of CPU?','[A].ComputerProcessingUnit [B].ComputerPrincipleUnit [C].CentralProcessingUnit [D].ControlProcessingUnit','C');
insert into mcq values(4,'which of the followinglanguage is written in binary codes only?','[A].Pascal [B].MachineLanguage [C].c [D].c#','B');
insert into mcq values(5,'which is the brain of computer?','[A].CPU [B].Memory [C].ArithmenticAndLogicalUnit [D].ControlUnit','A');
insert into mcq values(6,'which is the smallest unit of data?','[A].Bit [B].KB [C].Nibble [D].Byte','A');
insert into mcq values(7,'which is not type of computer codes?','[A].EDIC [B].ASCII [C].BCD [D].EBCDIC','A');
insert into mcq values(8,'which is the physical device of computer?','[A].Hardware [B].Software [C].SystemSoftware [D].Package','A');
insert into mcq values(9,'which is the following access the server?','[A].WebClient [B].User [C].WebBrowser [D].WebServer','A');
insert into mcq values(10,'which of the first neural network computer?','[A].AN [B].AM [C].RFD [D].SNARC','D');

