DROP TABLE question;

create table question()

